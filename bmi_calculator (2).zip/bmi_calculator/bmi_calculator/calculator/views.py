from .forms import BMIForm
from django.shortcuts import render

def bmi_calculator(request):
    return render(request, 'bmi_form.html')
def bmi_calculator(request):
    if request.method == 'POST':
        form = BMIForm(request.POST)
        if form.is_valid():
            weight = form.cleaned_data['weight']
            height = form.cleaned_data['height']
            bmi = weight / (height ** 2)
            return render(request, 'bmi_result.html', {'bmi': bmi})
    else:
        form = BMIForm()
    return render(request, 'bmi_form.html', {'form': form})



from django.shortcuts import render

def bmi_form(request):
    bmi = None
    category = None
    error_message = None

    if request.method == "POST":
        try:
            weight = float(request.POST.get('weight', 0))
            height = float(request.POST.get('height', 0)) / 100  # Convert cm to meters

            if weight <= 0 or height <= 0:
                error_message = "Weight and height must be greater than 0."
            else:
                bmi = weight / (height ** 2)
                if bmi < 18.5:
                    category = "Underweight"
                elif 18.5 <= bmi < 24.9:
                    category = "Normal weight"
                elif 25 <= bmi < 29.9:
                    category = "Overweight"
                else:
                    category = "Obesity"
        except ValueError:
            error_message = "Invalid input. Please provide numeric values."

    return render(request, 'bmi_result.html', {
        'bmi': bmi,
        'category': category,
        'error_message': error_message,
    })

def bmi_calculator(request):
    if request.method == 'POST':
        weight = float(request.POST['weight'])
        height = float(request.POST['height']) / 100  # Convert height to meters
        bmi = weight / (height ** 2)
        if bmi < 18.5:
            category = "Underweight"
        elif 18.5 <= bmi < 24.9:
            category = "Normal weight"
        elif 25 <= bmi < 29.9:
            category = "Overweight"
        else:
            category = "Obesity"
        return render(request, 'bmi_result.html', {'bmi': round(bmi, 2), 'category': category})
    return render(request, 'bmi_form.html')
